<script lang="ts" setup>
defineOptions({
  name: 'SettingsCity',
});
</script>

<template>fopkf</template>

<style scoped></style>
