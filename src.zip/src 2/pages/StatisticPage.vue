<template>
  <q-page class="row justify-evenly items-start q-pa-lg">
    <StatisticComponent />
  </q-page>
</template>

<script lang="ts" setup>
import StatisticComponent from 'src/components/Statistic/index.vue';
</script>

<style scoped></style>
