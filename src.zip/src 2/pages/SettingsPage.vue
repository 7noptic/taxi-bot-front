<template>
  <q-page class="row justify-evenly items-start q-pa-lg">
    <SettingsComponent />
  </q-page>
</template>

<script lang="ts" setup>
import SettingsComponent from 'src/components/Settings/index.vue';
</script>

<style scoped></style>
