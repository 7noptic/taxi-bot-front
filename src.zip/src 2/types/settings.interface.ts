export interface Settings {
  commission: number;
  priceText: string;
  faqText: string;
  aboutText: string;
  supportText: string;
}
