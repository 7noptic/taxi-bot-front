export * from './props.interface';
