export enum NewsletterType {
	All = 'all',
	Passengers = 'passengers',
	Drivers = 'drivers',
}
