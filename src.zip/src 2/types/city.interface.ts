export interface City {
  name: string;

  minPrice: number;
}
