export enum ModeTable {
  All = 'all-rows',
  Page = 'rows in page',
}
