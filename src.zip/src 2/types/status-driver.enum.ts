export enum StatusDriver {
  Online = 'online',
  Offline = 'offline',
}
