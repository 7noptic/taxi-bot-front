export enum StatusAppeal {
  Open = 'open',
  Close = 'close',
}

export const StatusAppealRus = {
  [StatusAppeal.Open]: '🔴 Открыто',
  [StatusAppeal.Close]: '✅ Закрыто',
};
