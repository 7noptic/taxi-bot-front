export interface Message {
  from: string;

  text: string;

  date: Date;
}
