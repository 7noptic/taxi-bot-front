export interface Admin {
  email: string;
  name: string;
}
