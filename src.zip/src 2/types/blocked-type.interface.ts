export enum BlockedType {
  No = 'no',
  NotPaid = 'notPaid',
  NotConfirmed = 'notConfirmed',
}
